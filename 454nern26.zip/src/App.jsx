import { useState } from "react";
import "./App.css";

// ============================================
// CLUB DATA
// ============================================

const clubs = [
  {
    id: 1,
    name: "CodeCraft Club",
    category: "Coding",
    description:
      "Learn programming, build projects, and participate in hackathons.",
    members: 86,
  },
  {
    id: 2,
    name: "Cricket Club",
    category: "Sports",
    description:
      "Play cricket, practice together, and participate in tournaments.",
    members: 64,
  },
  {
    id: 3,
    name: "Creative Arts Society",
    category: "Arts",
    description:
      "Explore painting, photography, drawing, design, and creativity.",
    members: 42,
  },
  {
    id: 4,
    name: "Startup Hub",
    category: "Entrepreneurship",
    description:
      "Develop startup ideas, learn business skills, and meet entrepreneurs.",
    members: 58,
  },
  {
    id: 5,
    name: "AI & Robotics Club",
    category: "Coding",
    description:
      "Explore artificial intelligence, robotics, and machine learning.",
    members: 73,
  },
  {
    id: 6,
    name: "Basketball Club",
    category: "Sports",
    description:
      "Practice basketball and participate in college competitions.",
    members: 39,
  },
];

// ============================================
// CLUB CARD COMPONENT
// ============================================

function ClubCard({ club, onViewDetails }) {
  return (
    <div className="club-card">
      <div className="club-icon">
        {club.name.charAt(0)}
      </div>

      <div className="club-content">
        <span className="category">
          {club.category}
        </span>

        <h2>{club.name}</h2>

        <p>{club.description}</p>

        <p className="members">
          👥 {club.members} members
        </p>

        <button
          className="details-button"
          onClick={() => onViewDetails(club)}
        >
          View Details
        </button>
      </div>
    </div>
  );
}

// ============================================
// CATEGORY FILTER COMPONENT
// ============================================

function CategoryFilter({ selected, onSelect }) {
  const categories = [
    "All",
    "Coding",
    "Sports",
    "Arts",
    "Entrepreneurship",
  ];

  return (
    <div className="filters">
      {categories.map((category) => (
        <button
          key={category}
          className={
            selected === category
              ? "filter-button active"
              : "filter-button"
          }
          onClick={() => onSelect(category)}
        >
          {category}
        </button>
      ))}
    </div>
  );
}

// ============================================
// CLUB DETAILS COMPONENT
// ============================================

function ClubDetails({
  club,
  onClose,
  onJoin,
  joined,
}) {
  // Conditional rendering
  if (!club) {
    return null;
  }

  return (
    <div className="modal-background">
      <div className="modal">
        <button
          className="close-button"
          onClick={onClose}
        >
          ×
        </button>

        <div className="large-icon">
          {club.name.charAt(0)}
        </div>

        <span className="category">
          {club.category}
        </span>

        <h2>{club.name}</h2>

        <p className="description">
          {club.description}
        </p>

        <div className="info">
          <strong>Members</strong>
          <span>{club.members}</span>
        </div>

        <div className="info">
          <strong>Category</strong>
          <span>{club.category}</span>
        </div>

        {/* Join button */}
        <button
          className={
            joined
              ? "join-button joined"
              : "join-button"
          }
          onClick={onJoin}
          disabled={joined}
        >
          {joined ? "Joined ✓" : "Join Club"}
        </button>
      </div>
    </div>
  );
}

// ============================================
// MAIN APP COMPONENT
// ============================================

function App() {
  // Search state
  const [search, setSearch] = useState("");

  // Category state
  const [selectedCategory, setSelectedCategory] =
    useState("All");

  // Selected club state
  const [selectedClub, setSelectedClub] =
    useState(null);

  // Joined state
  const [joined, setJoined] = useState(false);

  // ==========================================
  // FILTER CLUBS
  // ==========================================

  const filteredClubs = clubs.filter((club) => {
    const matchesSearch =
      club.name
        .toLowerCase()
        .includes(search.toLowerCase()) ||
      club.description
        .toLowerCase()
        .includes(search.toLowerCase());

    const matchesCategory =
      selectedCategory === "All" ||
      club.category === selectedCategory;

    return matchesSearch && matchesCategory;
  });

  // ==========================================
  // OPEN CLUB DETAILS
  // ==========================================

  function handleViewDetails(club) {
    setSelectedClub(club);

    // Reset Join button for the newly selected club
    setJoined(false);
  }

  // ==========================================
  // JOIN CLUB
  // ==========================================

  function handleJoinClub() {
    setJoined(true);
  }

  // ==========================================
  // RETURN UI
  // ==========================================

  return (
    <div className="app">
{/* Header / Banner */}
<header className="header">

  {/* Search + Filters */}
  <section className="search-section">

    <input
      className="search-input"
      type="text"
      placeholder="🔍 Search clubs..."
      value={search}
      onChange={(event) =>
        setSearch(event.target.value)
      }
    />

    <CategoryFilter
      selected={selectedCategory}
      onSelect={setSelectedCategory}
    />

  </section>

</header>

{/* Main content */}
<main className="container">
    
      
        {/* Results heading */}
        <div className="results-header">
          <h2>Explore Clubs</h2>

          <span>
            {filteredClubs.length} clubs found
          </span>
        </div>

        {/* Conditional rendering */}
        {filteredClubs.length > 0 ? (

          <div className="club-grid">

            {/* List rendering */}
            {filteredClubs.map((club) => (
              <ClubCard
                key={club.id}
                club={club}
                onViewDetails={
                  handleViewDetails
                }
              />
            ))}

          </div>

        ) : (

          <div className="empty-state">
            <div className="empty-icon">
              🔍
            </div>

            <h3>No clubs found</h3>

            <p>
              Try another search term or
              category.
            </p>
          </div>

        )}

      </main>

      {/* Club details modal */}
      <ClubDetails
        club={selectedClub}
        onClose={() =>
          setSelectedClub(null)
        }
        onJoin={handleJoinClub}
        joined={joined}
      />

    </div>
  );
}

export default App;
